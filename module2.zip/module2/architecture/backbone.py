import torch
from torch import nn
from torch.nn import functional as F
from torchvision import models
from torchvision.ops.misc import FrozenBatchNorm2d
from timm import create_model  # Untuk import Swin Transformer

import os
import torch
from timm import create_model
from pathlib import Path

def load_swin_model(pretrained=True, model_dir='pretrained_models'):
    model_name = 'swin_tiny_patch4_window7_224'
    os.makedirs(model_dir, exist_ok=True)
    
    model_path = Path(model_dir) / f'{model_name}.pth'
    
    if pretrained:
        if model_path.exists():
            print(f"Loading saved model from {model_path}")
            model = create_model(
                model_name, 
                pretrained=False, 
                num_classes=0,
                img_size=(512, 512)  # Sesuaikan dengan ukuran input
            )
            state_dict = torch.load(model_path)
            model.load_state_dict(state_dict, strict=False)  # strict=False karena mungkin ada perbedaan parameter
        else:
            print(f"Downloading model {model_name}...")
            model = create_model(
                model_name, 
                pretrained=True, 
                num_classes=0,
                img_size=(512, 512)  # Sesuaikan dengan ukuran input
            )
            torch.save(model.state_dict(), model_path)
            print(f"Model saved to {model_path}")
    else:
        model = create_model(
            model_name, 
            pretrained=False, 
            num_classes=0,
            img_size=(512, 512)  # Sesuaikan dengan ukuran input
        )
    
    return model


class Backbone(nn.Module):
    def __init__(
        self,
        backbone_name: str,  # Diganti dari 'name' ke 'backbone_name' untuk kejelasan
        pretrained: bool,
        dilation: bool,
        reduction: int,
        swav: bool,
        requires_grad: bool
    ):
        super(Backbone, self).__init__()
        self.reduction = reduction
        
        if backbone_name == 'swinT1k': 
            self.backbone = load_swin_model(
                pretrained=pretrained,
                model_dir='pretrained_models'
            )
            self.num_channels = 768
            if requires_grad:
                for param in self.backbone.parameters():
                    param.requires_grad_(True)
            else:
                for param in self.backbone.parameters():
                    param.requires_grad_(False)
                    
        else:
            # Existing ResNet handling
            resnet = getattr(models, backbone_name)(
                replace_stride_with_dilation=[False, False, dilation],
                pretrained=pretrained,
                norm_layer=FrozenBatchNorm2d
            )
            
            self.backbone = resnet
            self.num_channels = 896 if backbone_name in ['resnet18', 'resnet34'] else 3584

            if backbone_name == 'resnet50' and swav:
                checkpoint = torch.hub.load_state_dict_from_url(
                    'https://dl.fbaipublicfiles.com/deepcluster/swav_800ep_pretrain.pth.tar',
                    map_location="cpu"
                )
                state_dict = {k.replace("module.", ""): v for k, v in checkpoint.items()}
                self.backbone.load_state_dict(state_dict, strict=False)

            for n, param in self.backbone.named_parameters():
                if 'layer2' not in n and 'layer3' not in n and 'layer4' not in n:
                    param.requires_grad_(False)
                else:
                    param.requires_grad_(requires_grad)

    def forward(self, x):
        if hasattr(self.backbone, 'forward_features'):  # Untuk Swin
            x = self.backbone.forward_features(x)
            # Permutasi dimensi agar channel di posisi yang benar
            x = x.permute(0, 3, 1, 2)  # dari [B, H, W, C] ke [B, C, H, W]
            size = x.size(-2) // self.reduction, x.size(-1) // self.reduction
            return F.interpolate(x, size=size, mode='bilinear', align_corners=True)
        else:  # Untuk ResNet
            size = x.size(-2) // self.reduction, x.size(-1) // self.reduction
            x = self.backbone.conv1(x)
            x = self.backbone.bn1(x)
            x = self.backbone.relu(x)
            x = self.backbone.maxpool(x)

            x = self.backbone.layer1(x)
            x = layer2 = self.backbone.layer2(x)
            x = layer3 = self.backbone.layer3(x)
            x = layer4 = self.backbone.layer4(x)

            x = torch.cat([
                F.interpolate(f, size=size, mode='bilinear', align_corners=True)
                for f in [layer2, layer3, layer4]
            ], dim=1)
            
            return x